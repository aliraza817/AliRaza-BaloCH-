# AliRaza Baloch — Android starter, Phase 3

Features:
- Black-and-gold personal gallery UI.
- Select a reference photo.
- Request Android gallery permissions.
- Scan accessible photos and video first frames for face presence using on-device ML Kit.
- Manually confirm candidate media and save a separate confirmed album on-device.

Important: This build does NOT automatically recognize the selected person's identity. Face detection only finds media containing a face. The album contains only the files the user manually checks. Same-person biometric matching requires a separately validated on-device recognition model and should only be used with the pictured person's informed consent.

Build in Android Studio:
1. Open this folder.
2. Sync Gradle and install Android SDK 35 if prompted.
3. Run on an Android phone.
4. Select a reference image, grant gallery permission, scan, then manually check the correct items and save the album.
