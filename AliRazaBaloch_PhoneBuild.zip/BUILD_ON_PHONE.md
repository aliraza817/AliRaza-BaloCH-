# Build the AliRaza Baloch APK using only your phone

1. Create a **public or private** GitHub repository named `AliRazaBaloch` (do not add a README, license, or .gitignore).
2. Extract this ZIP on your phone.
3. In the repository, use **Add file → Upload files** and upload the *contents* of the extracted project, including the hidden `.github/workflows/build.yml` file. If the phone file picker hides dot-folders, use GitHub's web editor to create `.github/workflows/build.yml` and paste the workflow from this file's matching `build.yml` file.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab. Select **Build AliRaza Baloch APK**, tap **Run workflow**, then confirm.
6. When the run finishes successfully, open it and download the `AliRaza-Baloch-debug-apk` artifact. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.
7. Tap the APK to install. Android may ask permission to install apps from your browser or file manager.

Security: never share your GitHub password or personal access token in chat. The APK from this workflow is a debug build, not a Play Store release.

Important feature limitation: the current source detects faces in photos/video frames, but does not yet identify whether they belong to the same person as the chosen reference. The confirmed album is manually curated; this workflow does not magically add biometric identity matching.
