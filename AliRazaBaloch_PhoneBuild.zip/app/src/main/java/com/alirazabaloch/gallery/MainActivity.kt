package com.alirazabaloch.gallery

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.google.android.gms.tasks.Tasks

private val Gold = Color(0xFFE5BC62)
private val Black = Color(0xFF101010)
private val Panel = Color(0xFF211D16)

data class FaceMedia(val uri: Uri, val isVideo: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GalleryHome() }
    }
}

@Composable
fun GalleryHome() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var referencePhoto by remember { mutableStateOf<Uri?>(null) }
    var matches by remember { mutableStateOf<List<FaceMedia>>(emptyList()) }
    var status by remember { mutableStateOf("Pehle us person ki ek clear photo select karein.") }
    var scanning by remember { mutableStateOf(false) }
    val confirmed = remember { mutableStateListOf<String>() }
    var showAlbum by remember { mutableStateOf(false) }
    val prefs = remember { context.getSharedPreferences("confirmed_album", android.content.Context.MODE_PRIVATE) }
    LaunchedEffect(Unit) {
        confirmed.addAll(prefs.getStringSet("uris", emptySet()) ?: emptySet())
    }
    val scope = rememberCoroutineScope()

    val photoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        referencePhoto = uri
        status = if (uri != null) "Reference photo select ho gayi. Gallery scan kar sakte hain."
                  else "Koi photo select nahi hui."
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val granted = grants.values.any { it }
        if (granted) {
            scanning = true
            scope.launch {
                val result = withContext(Dispatchers.IO) { findMediaContainingFaces(context) }
                matches = result
                scanning = false
                status = "Gallery scan mukammal: ${result.size} files mein chehra detect hua."
            }
        } else {
            status = "Gallery access allow nahi hua. Settings se Photos/Videos permission dein."
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, background = Black, surface = Panel,
        onPrimary = Black, onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            modifier = Modifier.fillMaxSize().background(Black).padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("👑  AliRaza Baloch", color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("SMART PERSONAL GALLERY", color = Color.LightGray, fontSize = 10.sp,
                letterSpacing = 2.sp, modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(18.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("1. SELECT PERSON", color = Gold, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    if (referencePhoto != null) {
                        AsyncImage(model = referencePhoto, contentDescription = "Reference photo",
                            modifier = Modifier.size(112.dp), contentScale = ContentScale.Crop)
                    } else {
                        Box(Modifier.size(112.dp).background(Color(0xFF373025), RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center) {
                            Text("＋", color = Gold, fontSize = 42.sp)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { photoPicker.launch("image/*") },
                        colors = ButtonDefaults.buttonColors(containerColor = Gold)) {
                        Text("Choose reference photo", color = Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Button(
                enabled = referencePhoto != null && !scanning,
                onClick = {
                    val permissions = if (Build.VERSION.SDK_INT >= 34) arrayOf(
                        Manifest.permission.READ_MEDIA_IMAGES,
                        Manifest.permission.READ_MEDIA_VIDEO,
                        Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
                    ) else if (Build.VERSION.SDK_INT >= 33) arrayOf(
                        Manifest.permission.READ_MEDIA_IMAGES,
                        Manifest.permission.READ_MEDIA_VIDEO
                    ) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                    val missing = permissions.filter {
                        ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
                    }
                    if (missing.isEmpty()) {
                        scanning = true
                        scope.launch {
                            val result = withContext(Dispatchers.IO) { findMediaContainingFaces(context) }
                            matches = result
                            scanning = false
                            status = "Gallery scan mukammal: ${result.size} files mein chehra detect hua."
                        }
                    } else permissionLauncher.launch(missing.toTypedArray())
                },
                colors = ButtonDefaults.buttonColors(containerColor = Gold)
            ) { Text(if (scanning) "Scanning..." else "2. Scan my gallery", color = Black) }

            Spacer(Modifier.height(8.dp))
            Text(status, color = Color.LightGray, fontSize = 12.sp)
            Text("Face-containing files found: ${matches.size}", color = Gold, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { showAlbum = false }) { Text("Review", color = Gold) }
                OutlinedButton(onClick = { showAlbum = true }) { Text("My confirmed album (${confirmed.size})", color = Gold) }
            }
            if (!showAlbum) {
                Text("Review list — please confirm only photos of the selected person.",
                    color = Color.Gray, fontSize = 10.sp)
            } else {
                Text("Your manually confirmed album", color = Gold, fontSize = 12.sp)
            }
            LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth()) {
                items(if (showAlbum) matches.filter { confirmed.contains(it.uri.toString()) } else matches) { item ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                            .background(Panel, RoundedCornerShape(12.dp)).padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(model = item.uri, contentDescription = null,
                            modifier = Modifier.size(62.dp), contentScale = ContentScale.Crop)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(if (item.isVideo) "Video with detected face" else "Photo with detected face",
                                color = Color.White, fontWeight = FontWeight.Medium)
                            Text(item.uri.lastPathSegment ?: "Gallery item", color = Gold, fontSize = 10.sp)
                        }
                        Checkbox(
                            checked = confirmed.contains(item.uri.toString()),
                            onCheckedChange = { checked ->
                                if (checked) confirmed.add(item.uri.toString())
                                else confirmed.remove(item.uri.toString())
                            },
                            colors = CheckboxDefaults.colors(checkedColor = Gold, checkmarkColor = Black)
                        )
                    }
                }
            }
            if (!showAlbum) {
                Button(onClick = {
                    prefs.edit().putStringSet("uris", confirmed.toSet()).apply()
                    status = "${confirmed.size} items saved in your confirmed album."
                }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) {
                    Text("Save confirmed photos/videos", color = Black)
                }
            }
            Text("On-device processing • No face images uploaded", color = Color.Gray, fontSize = 10.sp)
        }
    }
}

private fun findMediaContainingFaces(context: android.content.Context): List<FaceMedia> {
    val options = FaceDetectorOptions.Builder()
        .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
        .build()
    val detector = FaceDetection.getClient(options)
    val found = mutableListOf<FaceMedia>()
    val collection = MediaStore.Files.getContentUri("external")
    val projection = arrayOf(
        MediaStore.Files.FileColumns._ID,
        MediaStore.Files.FileColumns.MEDIA_TYPE
    )
    val selection = "${MediaStore.Files.FileColumns.MEDIA_TYPE}=? OR ${MediaStore.Files.FileColumns.MEDIA_TYPE}=?"
    val args = arrayOf(
        MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
        MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString()
    )
    context.contentResolver.query(collection, projection, selection, args,
        "${MediaStore.Files.FileColumns.DATE_ADDED} DESC")?.use { cursor ->
        val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
        val typeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE)
        while (cursor.moveToNext()) {
            val id = cursor.getLong(idCol)
            val type = cursor.getInt(typeCol)
            val isVideo = type == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
            val uri = ContentUris.withAppendedId(collection, id)
            try {
                val input = if (isVideo) {
                    val retriever = MediaMetadataRetriever()
                    retriever.setDataSource(context, uri)
                    val frame: Bitmap? = retriever.getFrameAtTime(0)
                    retriever.release()
                    if (frame != null) InputImage.fromBitmap(frame, 0) else null
                } else {
                    InputImage.fromFilePath(context, uri)
                }
                if (input != null && Tasks.await(detector.process(input)).isNotEmpty()) {
                    found.add(FaceMedia(uri, isVideo))
                }
            } catch (_: Exception) {
                // Skip media that is unreadable or unsupported.
            }
        }
    }
    detector.close()
    return found
}
